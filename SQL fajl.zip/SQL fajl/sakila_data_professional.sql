-- MySQL dump (data only)
-- Host: localhost    Database: sakila
-- ------------------------------------------------------
-- Server version: 8.0 (simulated)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

USE sakila;

INSERT INTO director (first_name, last_name, date_of_birth) VALUES
('Roman', 'Polanski', '1933-08-18'),
('Andrei', 'Tarkovsky', '1932-04-04'),
('Alejandro', 'Amenábar', '1972-03-31'),
('Stanley', 'Kubrick', '1928-07-26');

SET FOREIGN_KEY_CHECKS = 1;
