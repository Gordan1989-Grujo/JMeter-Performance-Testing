-- MySQL dump (structure only)
-- Host: localhost    Database: sakila
-- ------------------------------------------------------
-- Server version: 8.0 (simulated)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

USE sakila;

DROP TABLE IF EXISTS director;

CREATE TABLE director (
    director_id INT NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    date_of_birth DATE,
    PRIMARY KEY (director_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
